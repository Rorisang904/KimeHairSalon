package za.ac.tut.model.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.model.bl.NailSalon;

@Stateless
public class NailSalonFacade extends AbstractFacade<NailSalon> implements NailSalonFacadeLocal {

    @PersistenceContext(unitName = "SalonEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public NailSalonFacade() {
        super(NailSalon.class);
    }

    @Override
public NailSalon findByCellNumber(String cellNumber) {
    try {
        NailSalon user = em.createQuery("SELECT n FROM NailSalon n WHERE n.cellNum = :cell", NailSalon.class)
                            .setParameter("cell", cellNumber)
                            .getSingleResult();
        System.out.println("User found: " + user.getName()); // Debugging log
        return user;
    } catch (Exception e) {
        System.out.println("Error retrieving user: " + e.getMessage()); // Debugging log
        return null;
    }
}

    @Override
    public List<NailSalon> viewList() {
        Query query = em.createQuery("SELECT n FROM NailSalon n");
        return query.getResultList();
    }
}
