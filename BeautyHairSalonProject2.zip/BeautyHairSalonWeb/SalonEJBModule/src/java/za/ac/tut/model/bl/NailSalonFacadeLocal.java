/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.model.bl;

import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author Mine
 */
@Local
public interface NailSalonFacadeLocal {

    void create(NailSalon nailSalon);

    void edit(NailSalon nailSalon);

    void remove(NailSalon nailSalon);

    NailSalon find(Object id);

    List<NailSalon> findAll();

    List<NailSalon> findRange(int[] range);

    int count();
     NailSalon findByCellNumber(String cellNumber);  
     List<NailSalon> viewList();
    
}
