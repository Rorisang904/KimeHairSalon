package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import za.ac.tut.model.bl.NailSalon;
import za.ac.tut.model.bl.NailSalonFacadeLocal;

@WebServlet(name = "RegisterClientSevlet", urlPatterns = {"/RegisterClientSevlet.do"})
public class RegisterClientSevlet extends HttpServlet {

    @EJB
    private NailSalonFacadeLocal ndfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String password = request.getParameter("password"); 
        String cell = request.getParameter("cell");

        NailSalon nl = ndfl.findByCellNumber(cell);
        
        

        if (nl != null && nl.getCellNum().equals(cell) && nl.getPassword().equals(password)) {
            RequestDispatcher disp = request.getRequestDispatcher("Menu.jsp");
            disp.forward(request, response);
        } else {
            request.setAttribute("errorMessage", "Invalid credentials. Please try again.");
            RequestDispatcher disp = request.getRequestDispatcher("login.html");
            disp.forward(request, response);
        }
    }
}