package za.ac.tut.web;

import java.io.IOException;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.model.bl.NailSalon;
import za.ac.tut.model.bl.NailSalonFacadeLocal;

public class AddClientSevlet extends HttpServlet {

    @EJB
    private NailSalonFacadeLocal nfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String cell = request.getParameter("cell");
        String password = request.getParameter("password");
        
        // Check if user already exists
        if (nfl.findByCellNumber(cell) != null) {
            request.setAttribute("errorMessage", "Cell Number already registered. Please login.");
            RequestDispatcher disp = request.getRequestDispatcher("login.html");
            disp.forward(request, response);
            return;
        }
        
        NailSalon nl = createNailSalon(name, email, cell, password);
        nfl.create(nl);
        
        request.setAttribute("successMessage", "Registration successful! Please login.");
        RequestDispatcher dips = request.getRequestDispatcher("login.html");
        dips.forward(request, response);
    }

    private NailSalon createNailSalon(String name, String email, String cell, String password) {
        NailSalon nl = new NailSalon();
        nl.setCellNum(cell);
        nl.setDate(new Date());
        nl.setEmail(email);
        nl.setName(name);
        nl.setPassword(password);
        return nl;
    }
}