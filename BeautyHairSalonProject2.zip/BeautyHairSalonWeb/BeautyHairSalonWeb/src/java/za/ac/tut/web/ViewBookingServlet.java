package za.ac.tut.web;

import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import za.ac.tut.model.bl.NailSalon;
import za.ac.tut.model.bl.NailSalonFacadeLocal;


public class ViewBookingServlet extends HttpServlet {
    @EJB 
    NailSalonFacadeLocal ndfl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String cellNumber = request.getParameter("cellNum").trim();

        NailSalon booking = ndfl.findByCellNumber(cellNumber);
        request.setAttribute("booking", booking);

        RequestDispatcher disp = request.getRequestDispatcher("ViewBookingOutcome.jsp");
        disp.forward(request, response);
    }
}
